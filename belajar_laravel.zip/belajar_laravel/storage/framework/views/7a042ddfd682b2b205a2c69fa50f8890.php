<h2>About Me</h2>
<p>Nama: <?php echo e($nama); ?></p>
<p>Mata Pelajaran: <?php echo e($mapel); ?></p>
<?php /**PATH /var/www/resources/views/about.blade.php ENDPATH**/ ?>