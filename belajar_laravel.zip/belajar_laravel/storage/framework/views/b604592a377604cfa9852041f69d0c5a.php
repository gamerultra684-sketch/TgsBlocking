<?php $__env->startSection('title', 'Daftar Buku'); ?>
<?php $__env->startSection('content'); ?>
    <h2 class="text-2xl font-bold mb-4">Daftar Buku</h2>

    <?php if(session('success')): ?>
    <div class="bg-green-100 text-green-800 p-2 mb-4 rounded">
        <?php echo e(session('success')); ?>

    </div>
    <?php endif; ?>

    <a href="<?php echo e(route('books.create')); ?>" class="bg-green-600 text-white px-3 py-1 rounded hover:bg-green-700">+ Tambah Buku</a>

    <table class="w-full bg-white rounded shadow-md mt-4">
        <thead>
            <tr class="bg-blue-700 text-white">
                <th class="p-2">Judul</th>
                <th class="p-2">Penulis</th>
                <th class="p-2">Penerbit</th>
                <th class="p-2">Tahun</th>
                <th class="p-2">Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr class="border-b hover:bg-gray-50">
                <td class="p-2"><?php echo e($book->title); ?></td>
                <td class="p-2"><?php echo e($book->author); ?></td>
                <td class="p-2"><?php echo e($book->publisher); ?></td>
                <td class="p-2"><?php echo e($book->year); ?></td>
                <td class="p-2 text-center">
                    <a href="<?php echo e(route('books.edit', $book->id)); ?>" class="text-blue-600 hover:underline">Edit</a> |
                    <form action="<?php echo e(route('books.destroy', $book->id)); ?>" method="POST" class="inline" onsubmit="return confirm('Yakin ingin menghapus buku ini?');">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="text-red-600 hover:underline">Hapus</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/resources/views/books/index.blade.php ENDPATH**/ ?>