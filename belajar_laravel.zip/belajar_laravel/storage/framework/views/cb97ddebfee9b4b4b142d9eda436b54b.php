<h1>Selamat Datang di Laravel</h1>
<p>Belajar Framework bersama BLOKING PPLG</p>
<?php /**PATH /var/www/resources/views/home.blade.php ENDPATH**/ ?>