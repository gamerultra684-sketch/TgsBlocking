<?php $__env->startSection('title', 'Tambah Buku'); ?>

<?php $__env->startSection('content'); ?>
<h2 class="text-2xl font-bold mb-6 text-slate-800">Tambah Buku Baru</h2>
<form action="/books/add" method="POST" class="bg-white p-8 rounded-xl shadow-lg border border-slate-100 space-y-5 transition-all hover:shadow-xl">
    <?php echo csrf_field(); ?>
    
    <div>
        <label class="block text-sm font-medium text-slate-600 mb-1">Judul Buku</label>
        <input type="text" name="title" placeholder="Masukkan judul buku" class="w-full border border-slate-300 p-3 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all" required>
    </div>
    
    <div>
        <label class="block text-sm font-medium text-slate-600 mb-1">Penulis</label>
        <input type="text" name="author" placeholder="Nama penulis" class="w-full border border-slate-300 p-3 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all" required>
    </div>
    
    <div>
        <label class="block text-sm font-medium text-slate-600 mb-1">Penerbit</label>
        <input type="text" name="publisher" placeholder="Nama penerbit" class="w-full border border-slate-300 p-3 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all">
    </div>
    
    <div>
        <label class="block text-sm font-medium text-slate-600 mb-1">Tahun Terbit</label>
        <input type="number" name="year" placeholder="Contoh: 2024" class="w-full border border-slate-300 p-3 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all">
    </div>
    
    <button type="submit" class="w-full bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-semibold px-4 py-3 rounded-lg transition-colors shadow-md mt-2">
        Simpan Buku
    </button>
</form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/resources/views/add-book.blade.php ENDPATH**/ ?>