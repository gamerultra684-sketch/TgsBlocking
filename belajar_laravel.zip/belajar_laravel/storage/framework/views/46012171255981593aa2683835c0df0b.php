<?php $__env->startSection('title', 'Tambah Buku'); ?>
<?php $__env->startSection('content'); ?>
    <h2 class="text-2xl font-bold mb-4">Tambah Buku</h2>

    <?php if($errors->any()): ?>
    <div class="bg-red-100 text-red-800 p-2 mb-4 rounded">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
    <?php endif; ?>

    <form action="<?php echo e(route('books.store')); ?>" method="POST" class="bg-white p-6 rounded shadow-md space-y-4">
        <?php echo csrf_field(); ?>
        <input type="text" name="title" placeholder="Judul Buku" class="w-full border p-2 rounded" required>
        <input type="text" name="author" placeholder="Penulis" class="w-full border p-2 rounded" required>
        <input type="text" name="publisher" placeholder="Penerbit" class="w-full border p-2 rounded">
        <input type="number" name="year" placeholder="Tahun Terbit" class="w-full border p-2 rounded">
        <button type="submit" class="bg-blue-700 text-white px-4 py-2 rounded">Simpan</button>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /var/www/resources/views/books/create.blade.php ENDPATH**/ ?>