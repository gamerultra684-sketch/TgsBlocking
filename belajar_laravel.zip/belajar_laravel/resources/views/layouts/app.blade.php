<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>@yield('title', 'Perpus Digital')</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;600;700&display=swap" rel="stylesheet">
    <style>
        body { font-family: 'Inter', sans-serif; }
    </style>
</head>
<body class="bg-slate-50 min-h-screen text-slate-800">
    <nav>
        <a href="/" class="mr-4 hover:underline font-semibold">Beranda</a>
        <a href="/about" class="mr-4 hover:underline font-semibold">Tentang</a>
        <a href="/contact" class="mr-4 hover:underline font-semibold">Kontak</a>
        <a href="/books" class="hover:underline font-semibold">Daftar Buku</a>
    </nav>

    <div class="container mx-auto mt-10 p-4 max-w-xl">
        @yield('content')
    </div>
</body>
</html>
