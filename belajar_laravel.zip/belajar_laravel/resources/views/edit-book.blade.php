@extends('layouts.app')

@section('title', 'Edit Buku')

@section('content')
<h2 class="text-2xl font-bold mb-6 text-slate-800">Edit Data Buku</h2>
<form action="/books/edit/{{ $book->id }}" method="POST" class="bg-white p-8 rounded-xl shadow-lg border border-slate-100 space-y-5 transition-all hover:shadow-xl">
    @csrf
    
    <div>
        <label class="block text-sm font-medium text-slate-600 mb-1">Judul Buku</label>
        <input type="text" name="title" value="{{ $book->title }}" placeholder="Masukkan judul buku" class="w-full border border-slate-300 p-3 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all" required>
    </div>
    
    <div>
        <label class="block text-sm font-medium text-slate-600 mb-1">Penulis</label>
        <input type="text" name="author" value="{{ $book->author }}" placeholder="Nama penulis" class="w-full border border-slate-300 p-3 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all" required>
    </div>
    
    <div>
        <label class="block text-sm font-medium text-slate-600 mb-1">Penerbit</label>
        <input type="text" name="publisher" value="{{ $book->publisher }}" placeholder="Nama penerbit" class="w-full border border-slate-300 p-3 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all">
    </div>
    
    <div>
        <label class="block text-sm font-medium text-slate-600 mb-1">Tahun Terbit</label>
        <input type="number" name="year" value="{{ $book->year }}" placeholder="Contoh: 2024" class="w-full border border-slate-300 p-3 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 outline-none transition-all">
    </div>
    
    <button type="submit" class="w-full bg-blue-600 hover:bg-blue-700 active:bg-blue-800 text-white font-semibold px-4 py-3 rounded-lg transition-colors shadow-md mt-2">
        Perbarui
    </button>
</form>
@endsection
