<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PageController extends Controller {
    public function index() {
        return view('home');
    }

    public function about() {
        $nama = "Ilham Ramadan";
        $mapel = "Bloking PPLG";
        return view('about', compact('nama', 'mapel'));
    }

    public function siswa() {
        $siswa = ['Andi', 'Budi', 'Citra', 'Dewi', 'Eko'];
        return view('siswa', compact('siswa'));
    }
}
